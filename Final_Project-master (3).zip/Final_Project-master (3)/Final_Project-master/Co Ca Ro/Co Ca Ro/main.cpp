﻿#include <iostream>
#include "_Common.h"
#include "_Menu.h"
using namespace std;

int main()
{
	_Common::setUpConsole();
	_Menu::mainScreen();
}